from flask import Flask


def register_extensions(app: Flask):
    # Placeholder for db, login_manager, etc. if you add later
    pass
